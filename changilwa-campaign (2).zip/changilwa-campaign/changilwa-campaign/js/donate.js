/* ============================================================
   Donation Page JS — Paystack + Multi-Currency
   ============================================================ */

'use strict';

// Exchange rates relative to KES
const EXCHANGE_RATES = {
  KES: 1,
  USD: 0.0077,
  EUR: 0.0071,
  GBP: 0.0060,
  UGX: 28.5,
  TZS: 19.8
};

const CURRENCY_SYMBOLS = {
  KES: 'KES',
  USD: '$',
  EUR: '€',
  GBP: '£',
  UGX: 'UGX',
  TZS: 'TZS'
};

const CURRENCY_FLAGS = {
  KES: '🇰🇪',
  USD: '🇺🇸',
  EUR: '🇪🇺',
  GBP: '🇬🇧',
  UGX: '🇺🇬',
  TZS: '🇹🇿'
};

// Base amounts in KES
const BASE_AMOUNTS_KES = [500, 1000, 2500, 5000, 10000, 25000];

let currentCurrency = 'KES';
let selectedAmount = 1000;
let customAmount = null;

function convertFromKES(kesAmount) {
  return Math.round(kesAmount * EXCHANGE_RATES[currentCurrency]);
}

function formatAmount(amount) {
  const sym = CURRENCY_SYMBOLS[currentCurrency];
  if (currentCurrency === 'KES' || currentCurrency === 'UGX' || currentCurrency === 'TZS') {
    return `${sym} ${amount.toLocaleString()}`;
  }
  return `${sym}${amount.toLocaleString()}`;
}

function renderAmountButtons() {
  const grid = document.getElementById('amountGrid');
  if (!grid) return;
  grid.innerHTML = '';
  BASE_AMOUNTS_KES.forEach(kes => {
    const converted = convertFromKES(kes);
    const btn = document.createElement('button');
    btn.className = 'amount-btn' + (kes === selectedAmount ? ' active' : '');
    btn.textContent = formatAmount(converted);
    btn.dataset.kes = kes;
    btn.addEventListener('click', () => {
      selectedAmount = kes;
      customAmount = null;
      document.getElementById('customAmount').value = '';
      document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      updateSummary();
    });
    grid.appendChild(btn);
  });
}

function updateSummary() {
  const amountEl = document.getElementById('summaryAmount');
  const currencyEl = document.getElementById('summaryCurrency');
  if (!amountEl) return;
  const kes = customAmount || selectedAmount;
  const converted = convertFromKES(kes);
  amountEl.textContent = formatAmount(converted);
  if (currencyEl) currencyEl.textContent = currentCurrency;
  updateImpact(kes);
}

function updateImpact(kesAmount) {
  const impacts = document.querySelectorAll('.impact-dynamic');
  impacts.forEach(el => {
    const multiplier = parseFloat(el.dataset.multiplier || '1');
    const base = parseInt(el.dataset.base || '1', 10);
    const value = Math.max(1, Math.floor((kesAmount / base) * multiplier));
    el.textContent = value.toLocaleString();
  });
}

function initCurrencyButtons() {
  document.querySelectorAll('.currency-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      currentCurrency = btn.dataset.currency;
      document.querySelectorAll('.currency-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderAmountButtons();
      updateSummary();

      // Update custom placeholder
      const customInput = document.getElementById('customAmount');
      if (customInput) {
        customInput.placeholder = `Or enter custom (${CURRENCY_SYMBOLS[currentCurrency]})`;
      }
    });
  });
}

function initCustomAmount() {
  const input = document.getElementById('customAmount');
  if (!input) return;
  input.addEventListener('input', () => {
    const val = parseFloat(input.value);
    if (val && val > 0) {
      // Convert from current currency back to KES
      customAmount = Math.round(val / EXCHANGE_RATES[currentCurrency]);
      document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('active'));
      updateSummary();
    } else {
      customAmount = null;
    }
  });
}

function initDonateBtn() {
  const btn = document.getElementById('donateBtn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    const email = document.getElementById('donorEmail');
    const name = document.getElementById('donorName');

    if (!email || !email.value || !name || !name.value) {
      if (typeof showToast === 'function') {
        showToast('⚠️ Please enter your name and email address.', 'error');
      } else {
        alert('Please enter your name and email address.');
      }
      return;
    }

    const kes = customAmount || selectedAmount;
    const converted = convertFromKES(kes);

    // Paystack amount is in the smallest currency unit
    // KES uses kobo equivalent (100 = 1 KES)
    const paystackAmount = currentCurrency === 'KES'
      ? kes * 100
      : Math.round(converted * 100);

    // Map currencies to Paystack supported codes
    const paystackCurrencies = { KES: 'KES', USD: 'USD', EUR: 'EUR', GBP: 'GBP', UGX: 'UGX', TZS: 'TZS' };
    const paystackCurrency = paystackCurrencies[currentCurrency] || 'KES';

    const handler = PaystackPop.setup({
      key: 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', // Replace with your Paystack public key
      email: email.value,
      amount: paystackAmount,
      currency: paystackCurrency,
      ref: 'CHANGILWA-' + Date.now(),
      metadata: {
        name: name.value,
        campaign: 'Maxwell Changilwa MCA 2027',
        ward: 'Kabiro Ward'
      },
      callback: function(response) {
        showDonationSuccess(name.value, formatAmount(converted));
      },
      onClose: function() {
        console.log('Donation window closed');
      }
    });
    handler.openIframe();
  });
}

function showDonationSuccess(name, amount) {
  const overlay = document.getElementById('successOverlay');
  if (overlay) {
    const nameEl = overlay.querySelector('.success-name');
    const amountEl = overlay.querySelector('.success-amount');
    if (nameEl) nameEl.textContent = name;
    if (amountEl) amountEl.textContent = amount;
    overlay.style.display = 'flex';
    setTimeout(() => overlay.style.opacity = '1', 10);
  } else {
    alert(`Thank you, ${name}! Your donation of ${amount} has been received. Asante sana!`);
  }
}

/* ===== M-PESA STK PUSH SIMULATION ===== */
function initMpesa() {
  const mpesaForm = document.getElementById('mpesaForm');
  if (!mpesaForm) return;
  mpesaForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const phone = document.getElementById('mpesaPhone').value;
    if (!phone) return;
    const btn = mpesaForm.querySelector('button');
    btn.textContent = 'Sending prompt...';
    btn.disabled = true;
    setTimeout(() => {
      if (typeof showToast === 'function') {
        showToast('📱 M-Pesa prompt sent to ' + phone + '. Please complete payment on your phone.');
      }
      btn.textContent = 'Send M-Pesa Prompt';
      btn.disabled = false;
      mpesaForm.reset();
    }, 2000);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderAmountButtons();
  initCurrencyButtons();
  initCustomAmount();
  initDonateBtn();
  initMpesa();
  updateSummary();
});
